export class ErrorModel {
    Message: string;
    LogType: string;
    constructor() {
    }
}
