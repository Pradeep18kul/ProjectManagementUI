export class UserModel {
    UserId: number;
    FirstName: string;
    LastName: string;
    EmployeeId: number;

    constructor() {
    }
}
