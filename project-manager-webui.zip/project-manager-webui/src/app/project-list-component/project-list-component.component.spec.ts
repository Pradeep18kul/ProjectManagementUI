// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { ProjectListComponentComponent } from './project-list-component.component';

// describe('ProjectListComponentComponent', () => {
//   let component: ProjectListComponentComponent;
//   let fixture: ComponentFixture<ProjectListComponentComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ ProjectListComponentComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(ProjectListComponentComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
