﻿namespace ProjectManager.Business.ServiceRequests
{
    public class LogRequest
    {
        public string Message { get; set; }
        public string LogType { get; set; }
    }
}
